$(function() {
console.log('conectado el dom');

$('[data-toggle="tooltip"]').tooltip()
}
});
